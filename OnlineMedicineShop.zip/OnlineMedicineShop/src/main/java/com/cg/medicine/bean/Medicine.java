package com.cg.medicine.bean;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.SequenceGenerator;

@SequenceGenerator(name="sequenceMedicine",initialValue=1001,allocationSize=1)
@Entity
public class Medicine {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sequenceMedicine")
private int medicineID;
private String medicineName;
private float price;
private String manufactureDate;
private String expiryDate;
private String manufacturingCompany;
private int stockQuantity;
@ManyToOne
@MapKey
@JoinColumn(name="customerID")
private Customer customer;
public Medicine() {
	super();
}


public Medicine(int medicineID, String medicineName, float price, String manufactureDate, String expiryDate,
		String manufacturingCompany, int stockQuantity) {
	super();
	this.medicineID = medicineID;
	this.medicineName = medicineName;
	this.price = price;
	this.manufactureDate = manufactureDate;
	this.expiryDate = expiryDate;
	this.manufacturingCompany = manufacturingCompany;
	this.stockQuantity = stockQuantity;
}


public int getMedicineID() {
	return medicineID;
}
public void setMedicineID(int medicineID) {
	this.medicineID = medicineID;
}
public String getMedicineName() {
	return medicineName;
}
public void setMedicineName(String medicineName) {
	this.medicineName = medicineName;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public String getManufactureDate() {
	return manufactureDate;
}
public void setManufactureDate(String manufactureDate) {
	this.manufactureDate = manufactureDate;
}
public String getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(String expiryDate) {
	this.expiryDate = expiryDate;
}
public String getManufacturingCompany() {
	return manufacturingCompany;
}
public void setManufacturingCompany(String manufacturingCompany) {
	this.manufacturingCompany = manufacturingCompany;
}
public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}
public int getStockQuantity() {
	return stockQuantity;
}
public void setStockQuantity(int stockQuantity) {
	this.stockQuantity = stockQuantity;
}


@Override
public String toString() {
	return "Medicine [medicineID=" + medicineID + ", medicineName=" + medicineName + ", price=" + price
			+ ", manufactureDate=" + manufactureDate + ", expiryDate=" + expiryDate + ", manufacturingCompany="
			+ manufacturingCompany + ", stockQuantity=" + stockQuantity + "]";
}


}
