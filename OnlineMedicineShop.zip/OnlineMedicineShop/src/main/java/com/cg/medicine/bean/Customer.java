package com.cg.medicine.bean;




import java.util.Map;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;


@SequenceGenerator(name="sequenceCustomer",initialValue=1001,allocationSize=1)
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sequenceCustomer")
	private int customerID;
	@NotEmpty
	private String firstName;
	@NotEmpty
	private String lastName;
	@NotEmpty
	private String emailID;
	@NotEmpty
	private String dateOfBirth;
	private long mobileNo;
	@Embedded
	@Valid
	private Address billingAddress;
	@MapKey
	@OneToMany
	private Map<Integer,Medicine> medicines;
	public Customer() {
	
	}
	
	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Customer(@NotEmpty String firstName, @NotEmpty String lastName, @NotEmpty String emailID,
			@NotEmpty String dateOfBirth, long mobileNo, @Valid Address billingAddress) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.billingAddress = billingAddress;
	}

	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}
	public Map<Integer, Medicine> getMedicines() {
		return medicines;
	}
	public void setMedicines(Map<Integer, Medicine> medicines) {
		this.medicines = medicines;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailID=" + emailID + ", dateOfBirth=" + dateOfBirth + ", mobileNo=" + mobileNo
				+ ", billingAddress=" + billingAddress + "]";
	}
	
	
}
