package com.cg.medicine.exception;

public class MedicineOutOfStockException extends Exception {

	public MedicineOutOfStockException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MedicineOutOfStockException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MedicineOutOfStockException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MedicineOutOfStockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MedicineOutOfStockException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
