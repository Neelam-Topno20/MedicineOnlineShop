package com.cg.medicine.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.medicine.bean.Medicine;

@Qualifier("JpaRepository")
public interface MedicineDAOServices extends JpaRepository<Medicine, Integer>{
	
	@Query(value="SELECT * FROM MEDICINE WHERE MEDICINENAME=?1",nativeQuery=true)
	Medicine findMedicineByID(String medicineName); 

}
