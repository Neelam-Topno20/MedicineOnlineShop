package com.cg.medicine.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class URIController {

	@RequestMapping(value= {"/","/home","index"})
	String getIndexPage() {
		return "indexPage";
	}
}
