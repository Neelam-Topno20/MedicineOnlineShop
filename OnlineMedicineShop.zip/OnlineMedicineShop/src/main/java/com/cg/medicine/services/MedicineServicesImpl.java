package com.cg.medicine.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.cg.medicine.bean.Customer;
import com.cg.medicine.bean.Medicine;
import com.cg.medicine.daoservices.CustomerDAOServices;
import com.cg.medicine.daoservices.MedicineDAOServices;
import com.cg.medicine.exception.CustomerNotFoundException;
import com.cg.medicine.exception.InsufficientStockException;
import com.cg.medicine.exception.MedicineNotFoundException;
import com.cg.medicine.exception.MedicineOutOfStockException;

public class MedicineServicesImpl implements MedicineServices{
	
	@Autowired
	CustomerDAOServices customerDAOServices;
	@Autowired
	MedicineDAOServices medicineDAOServices;
	
	
	public MedicineServicesImpl() {

	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customer=customerDAOServices.save(customer);
		return null;
	}

	@Override
	public Medicine acceptMedicineDetails(Medicine medicine) {
		medicine=medicineDAOServices.save(medicine);
		return medicine;
	}

	@Override
	public boolean buyMedicine(String medicineName, int quantity) throws MedicineOutOfStockException, MedicineNotFoundException, InsufficientStockException {
		Medicine medicine=medicineDAOServices.findMedicineByID(medicineName);
		if(medicine==null)
			throw new MedicineNotFoundException();
		if(medicine.getStockQuantity()<=0)
			throw new MedicineOutOfStockException();
		if(medicine.getStockQuantity()<quantity)
			throw new InsufficientStockException();
		
		medicine.setStockQuantity(medicine.getStockQuantity()-quantity);
		medicine=medicineDAOServices.save(medicine);
		
		return true;
	}

	@Override
	public List<Medicine> viewAllMedicines() {
		return medicineDAOServices.findAll();
	}

	@Override
	public List<Customer> viewAllCustomers() {
		return customerDAOServices.findAll();
	}

	@Override
	public boolean deleteMedicine(int medicineID) throws MedicineNotFoundException {
		medicineDAOServices.findById(medicineID).orElseThrow(()->new MedicineNotFoundException());
		medicineDAOServices.deleteById(medicineID);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID) throws CustomerNotFoundException {
		customerDAOServices.findById(customerID).orElseThrow(()->new CustomerNotFoundException());
		customerDAOServices.deleteById(customerID);
		return true;
	}

	@Override
	public boolean updateMedicine(int medicineID, int quantity) throws MedicineNotFoundException {
		medicineDAOServices.findById(medicineID).orElseThrow(()->new MedicineNotFoundException());
		Medicine medicine=medicineDAOServices.findById(medicineID).get();
		medicine.setStockQuantity(medicine.getStockQuantity()+quantity);
		medicine=medicineDAOServices.save(medicine);
		return true;
	}

	@Override
	public boolean updateCustomerMobileNo(int customerID, long mobileNo) throws CustomerNotFoundException {
		customerDAOServices.findById(customerID).orElseThrow(()->new CustomerNotFoundException());
		Customer customer=customerDAOServices.findById(customerID).get();
		customer.setMobileNo(mobileNo);
		customer=customerDAOServices.save(customer);
		return true;
	}

	@Override
	public boolean updateCustomerAddress(Customer customer) throws CustomerNotFoundException {
		Customer customer1=customerDAOServices.findById(customer.getCustomerID()).orElseThrow(()->new CustomerNotFoundException());
		customer1.setBillingAddress(customer.getBillingAddress());
		customer=customerDAOServices.save(customer);
		return true;
	}

}
