package com.cg.medicine.services;

import java.util.List;

import com.cg.medicine.bean.Customer;
import com.cg.medicine.bean.Medicine;
import com.cg.medicine.exception.CustomerNotFoundException;
import com.cg.medicine.exception.InsufficientStockException;
import com.cg.medicine.exception.MedicineNotFoundException;
import com.cg.medicine.exception.MedicineOutOfStockException;

public interface MedicineServices {
 Customer acceptCustomerDetails(Customer customer);
 Medicine acceptMedicineDetails(Medicine medicine);
 boolean buyMedicine(String medicineName,int quantity) throws MedicineOutOfStockException, MedicineNotFoundException, InsufficientStockException;
 List<Medicine> viewAllMedicines();
 List<Customer> viewAllCustomers();
boolean deleteMedicine(int medicineID) throws MedicineNotFoundException;
boolean deleteCustomer(int customerID) throws CustomerNotFoundException;
boolean updateMedicine(int medicineID,int quantity) throws MedicineNotFoundException;
boolean updateCustomerMobileNo(int customerID,long mobileNo) throws CustomerNotFoundException;
boolean updateCustomerAddress(Customer customer) throws CustomerNotFoundException;
}
