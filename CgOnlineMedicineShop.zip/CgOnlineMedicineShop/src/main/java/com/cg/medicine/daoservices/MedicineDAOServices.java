package com.cg.medicine.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.medicine.beans.Medicine;
@Qualifier("JpaRepository")
public interface MedicineDAOServices extends JpaRepository<Medicine, Integer>{
	@Query(value="select * from Medicine where medicine_Name=?1",nativeQuery=true)
	Medicine findMedicine(String medicineName);
	@Transactional
	@Modifying
	@Query(value="update Medicine set stock_quantity=?2 where medicine_id=?1",nativeQuery=false)
	int updateMedicine(int medicineId,int quantity);
}
