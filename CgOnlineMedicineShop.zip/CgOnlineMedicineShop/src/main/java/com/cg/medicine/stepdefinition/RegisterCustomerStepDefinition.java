package com.cg.medicine.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterCustomerStepDefinition {
	@Given("^User is on the Online Medicine Portal 'indexPage' check Customer Reistration$")
	public void user_is_on_the_Online_Medicine_Portal_indexPage_check_Customer_Reistration() throws Throwable {
	
	}

	@When("^User clicks 'Register New Customer ' button for error condition$")
	public void user_clicks_Register_New_Customer_button_for_error_condition() throws Throwable {
	  
	}

	@Then("^Displayed 'Register New Customer Error Message' on 'registerCustomerPage'$")
	public void displayed_Register_New_Customer_Error_Message_on_registerCustomerPage() throws Throwable {
	 
	}

	@When("^User clicks 'Register New Customer ' button for successful operation$")
	public void user_clicks_Register_New_Customer_button_for_successful_operation() throws Throwable {
	
	}

	@Then("^Successful registration and show message on 'registerSuccessPage'$")
	public void successful_registration_and_show_message_on_registerSuccessPage() throws Throwable {
	
	}


}
