package com.cg.medicine.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {
	@FindBy(how=How.NAME,name="allMedicineDetails")
	private WebElement viewAllMedicineButton;
	
	@FindBy(how=How.CLASS_NAME,className="errorMessage")
	private WebElement errorMessage;
	
	public IndexPage() {
		super();
	}

	public String getErrorMessage() {
		return errorMessage.getText();
	}

	public void 	clickviewAllMedicineButton() {
		viewAllMedicineButton.click();
	}
}
