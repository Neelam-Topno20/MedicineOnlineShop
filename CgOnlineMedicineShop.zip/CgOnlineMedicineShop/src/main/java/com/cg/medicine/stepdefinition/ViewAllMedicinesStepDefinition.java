package com.cg.medicine.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.medicine.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllMedicinesStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;

@Given("^User is on the Online Medicine Portal 'indexPage'$")
public void user_is_on_the_Online_Medicine_Portal_indexPage() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	driver.get("http://localhost:8078/home");
	String actualTitle=driver.getTitle();
	String expectedTitle="MedicineShop";
	Assert.assertEquals(expectedTitle, actualTitle);
	indexPage=PageFactory.initElements(driver, IndexPage.class);
}

@When("^User clicks 'View All Medicines ' button for error condition$")
public void user_clicks_View_All_Medicines_button_for_error_condition() throws Throwable {
indexPage.clickviewAllMedicineButton();
}

@Then("^Displayed 'View All Medicine Error Message' on 'indexPage'$")
public void displayed_View_All_Medicine_Error_Message_on_indexPage() throws Throwable {
  String actualErrorMessage=indexPage.getErrorMessage();
  String expectedErrorMessage="Medicines Not Available";
  Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
  
}

@When("^User clicks on 'View All Medicines ' button for succesful execution$")
public void user_clicks_on_View_All_Medicines_button_for_succesful_execution() throws Throwable {
	indexPage.clickviewAllMedicineButton();
}

@Then("^Display 'All Medicines' on 'View All Medicines Page'$")
public void display_All_Medicines_on_View_All_Medicines_Page() throws Throwable {
	String actualTitle=driver.getTitle();
	String expectedTitle="Medicines";
	Assert.assertEquals(expectedTitle, actualTitle);
}


}
