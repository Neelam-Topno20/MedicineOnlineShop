package com.cg.medicine.controllers;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.medicine.beans.Customer;
import com.cg.medicine.beans.Medicine;
import com.cg.medicine.exceptions.CustomerNotFoundException;
import com.cg.medicine.exceptions.InsufficientStockException;
import com.cg.medicine.exceptions.MedicineNotFoundException;
import com.cg.medicine.exceptions.MedicineServicesDownExcepton;
import com.cg.medicine.exceptions.OutOfStockException;
import com.cg.medicine.services.MedicineServices;
@Controller
public class MedicineController {
	@Autowired
	MedicineServices medicineServices;
	Customer customer;
	Medicine medicine;
	@RequestMapping("/allMedicineDetails")
	public ModelAndView medicineDetailsAction() {
		List<Medicine> listMedicine;
		try {
			listMedicine = medicineServices.viewAllMedicine();
		} catch (MedicineNotFoundException e) {
			return new ModelAndView("indexPage","errorMessage","Medicines Not Available");
		}
		return new ModelAndView("displayAllMedicinePage","listMedicine",listMedicine);
	}
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer) {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("getCustomerDetailsPage");
		try {
			customer=medicineServices.acceptCustomerDetails(customer);
		} catch (MedicineServicesDownExcepton e) {
			return new ModelAndView("getCustomerDetailsPage","errorMessaage","Error Occured!!!!!Please Try Again");
		}
		return new ModelAndView("registerSuccessPage","customer",customer);
	}
	@RequestMapping("/medicine")
	public ModelAndView registerMedicineAction(@Valid@ModelAttribute Medicine medicine,BindingResult bindingResultMedicine){
		if(bindingResultMedicine.hasErrors())
			return new ModelAndView("getMedicineDetailsPage");
		try {
			medicine=medicineServices.acceptMedicineDetails(medicine);
		} catch (MedicineServicesDownExcepton e) {
			return new ModelAndView("getMedicineDetailsPage","errorMessaage","Error Occured!!!!!Please Try Again");
		}
		return new ModelAndView("adminIndexPage","successMessage","Medicine Registered Successfully in Stock");
	}
	@RequestMapping("/buyMedicine")
	public ModelAndView buyMedicineAction(@RequestParam("customerId") int customerId,@RequestParam("medicineName") String medicineName,@RequestParam("quantity") int quantity){
			try{
					medicineServices.buyMedicine(customerId,medicineName,quantity);
			}catch (CustomerNotFoundException e) {
				return new ModelAndView("getMedicineNamePage","errorMessage","Customer Not Found!!!!!First Register Yourself");
			}catch (MedicineServicesDownExcepton e){
				return new ModelAndView("getMedicineNamePage","errorMessage","Error Occured!!!!!Please Try Again");
			}catch (MedicineNotFoundException e){
				return new ModelAndView("getMedicineNamePage","errorMessage","Medicine Not Found!!!!!Please Try Another Medicine");
			} catch (OutOfStockException e) {
				return new ModelAndView("getMedicineNamePage","errorMessage","Medicine Not Found!!!!!Please Try Another Medicine");
			} catch (InsufficientStockException e) {
				return new ModelAndView("getMedicineNamePage","errorMessage","Insufficient Medicine Quantity!!!!!");
			} 
		return new ModelAndView("customerIndexPage","successMessage","Medicine Purchased Successfully");
	}
	@RequestMapping("/viewCustomerMedicine")
	public ModelAndView viewCustomerMedicineAction(@RequestParam("customerId") int customerId){
		List<Medicine> listMedicine;
		try {
			listMedicine=medicineServices.viewCustomerMedicine(customerId);
		} catch (CustomerNotFoundException e) {
			return new ModelAndView("customerIndexPage","errorMessage","Customer Not Found!!!!!First Register Yourself");
		} catch (MedicineNotFoundException e) {
			return new ModelAndView("customerIndexPage","errorMessage","No Medicines Found!");
		}
		return new ModelAndView("displayCustomerMedicinePage","listMedicine",listMedicine);
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomerAction(@RequestParam("customerId") int customerId){
			try {
				medicineServices.deleteCustomer(customerId);
			} catch (CustomerNotFoundException e) {
				return new ModelAndView("getDeleteCustomerIdPage","errorMessage","Customer Not Found!!!!!First Register Yourself");
			}
			return new ModelAndView("customerIndexPage","successMessage","Customer Successfully deleted");
	}
	@RequestMapping("/getUpdateAddress")
	public ModelAndView updateAddressAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer){
		try {
			medicineServices.updateCustomerAddress(customer);
		} catch (CustomerNotFoundException e) {
			return new ModelAndView("customerIndexPage","errorMessage","Customer Not Found!!!!!First Register Yourself");
		}
		return new ModelAndView("customerIndexPage","successMessage","Your Addresss Successfully Updated");
	}
	@RequestMapping("/getUpdateMobile")
	public ModelAndView updateMobileNoAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer){
		try {
			medicineServices.updateCustomerMobileNo(customer.getCustomerId(),customer.getMobileNo());
		} catch (CustomerNotFoundException e) {
			return new ModelAndView("customerIndexPage","errorMessage","Customer Not Found!!!!!First Register Yourself");
		}
		return new ModelAndView("customerIndexPage","successMessage","Your Mobile No Successfully Updated");
	}
	@RequestMapping("/viewAllCustomer")
	public ModelAndView viewAllCustomerAction(){
		List<Customer> listCustomer;
		try {
			listCustomer = medicineServices.viewAllCustomer();
		} catch (CustomerNotFoundException e) {
			return new ModelAndView("adminIndexPage","errorMessage","No Customer record found!");
		}
		return new ModelAndView("displayAllCustomerPage","listCustomer",listCustomer);
	}
	@RequestMapping("/getDeleteMedicine")
	public ModelAndView deleteMedicineAction(@Valid@ModelAttribute Medicine medicine,BindingResult bindingResultMedicine){
		try {
			medicineServices.deleteMedicine(medicine.getMedicineId());
		} catch (MedicineNotFoundException e) {
			return new ModelAndView("adminIndexPage","errorMessage","Medicine Not Found!!!!!");
		}
		return new ModelAndView("adminIndexPage","successMessage","Medicine has been deleted Successfully");
	}
	@RequestMapping("/getUpdateMedicine")
	public ModelAndView updateMedicineAction(@Valid@ModelAttribute Medicine medicine,BindingResult bindingResultMedicine){
		try {
			medicineServices.updateMedicine(medicine.getMedicineId(), medicine.getStockQuantity());
		} catch (MedicineNotFoundException e) {
			return new ModelAndView("adminIndexPage","errorMessage","Medicine Not Found!!!!!");
		}
		return new ModelAndView("adminIndexPage","successMessage","Medicine has been updated Successfully");
	}
}
