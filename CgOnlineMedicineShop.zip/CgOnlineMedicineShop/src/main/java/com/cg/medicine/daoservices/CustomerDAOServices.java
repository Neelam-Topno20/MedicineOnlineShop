package com.cg.medicine.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.medicine.beans.Customer;
@Qualifier("JpaRepository")
public interface CustomerDAOServices extends JpaRepository<Customer, Integer>{
}
