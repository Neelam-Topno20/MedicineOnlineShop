package com.cg.medicine.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.medicine.beans.Customer;
import com.cg.medicine.beans.Medicine;
import com.cg.medicine.daoservices.CustomerDAOServices;
import com.cg.medicine.daoservices.MedicineDAOServices;
import com.cg.medicine.exceptions.CustomerNotFoundException;
import com.cg.medicine.exceptions.InsufficientStockException;
import com.cg.medicine.exceptions.MedicineNotFoundException;
import com.cg.medicine.exceptions.MedicineServicesDownExcepton;
import com.cg.medicine.exceptions.OutOfStockException;
@Component("medicineServices")
public class MedicineServicesImpl  implements MedicineServices{
	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private MedicineDAOServices medicineDAOServices;
	@Override
	public Customer acceptCustomerDetails(Customer customer) throws MedicineServicesDownExcepton{
		customer=customerDAOServices.save(customer);
		return customer;
	}

	@Override
	public Medicine acceptMedicineDetails(Medicine medicine) throws MedicineServicesDownExcepton{
		medicine=medicineDAOServices.save(medicine);
		return medicine;
	}

	@Override
	public boolean buyMedicine(int customerId,String medicineName, int quantity) throws MedicineServicesDownExcepton,MedicineNotFoundException, OutOfStockException, InsufficientStockException, CustomerNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		Medicine medicine=medicineDAOServices.findMedicine(medicineName);
		if(medicine==null)
			throw new MedicineNotFoundException();
		if(medicine.getStockQuantity()<=0)
			throw new OutOfStockException();
		if(medicine.getStockQuantity()<quantity)
			throw new InsufficientStockException();
		int st=medicine.getStockQuantity();
		medicine.setCustomer(customer);
		medicine.setStockQuantity(quantity);
		//Map<Integer, Medicine> mapMedicine=new HashMap<>();
		//mapMedicine.put(medicine.getMedicineId(), medicine);
		//customer.setMedicine(mapMedicine);
		
	
		//customerDAOServices.save(customer);
		medicineDAOServices.save(medicine);
		medicineDAOServices.updateMedicine(medicine.getMedicineId(),st-quantity);
		//medicine.setStockQuantity(st-quantity);
		//medicineDAOServices.m
		//medicine.setStockQuantity(st-quantity);
		//medicineDAOServices.save(medicine);
		
		/*
		Medicine medicine2=new Medicine();
		medicine2.setDateOfExpiry(medicine.getDateOfExpiry());
		medicine2.setDateOfManufacturer(medicine.getDateOfManufacturer());
		medicine2.setMedicineId(medicine.getMedicineId());
		medicine2.setManufacturerCompany(medicine.getManufacturerCompany());
		medicine2.setMedicineName(medicine.getMedicineName());
		medicine2.setMedicinePrice(medicine.getMedicinePrice());
		medicine2.setStockQuantity(quantity);
		Map<Integer, Medicine> mapMedicine=new HashMap<>();
		mapMedicine.put(medicine.getMedicineId(), medicine2);
		customer.setMedicine(mapMedicine);
		customerDAOServices.save(customer);
		medicineDAOServices.save(medicine);*/
		return true;
	}

	@Override
	public List<Medicine> viewAllMedicine() throws MedicineNotFoundException {
		List<Medicine> medicineList=medicineDAOServices.findAll();
		if(medicineList.isEmpty())
			throw new MedicineNotFoundException();
		return medicineList;
	}

	@Override
	public List<Customer> viewAllCustomer() throws CustomerNotFoundException {
		List<Customer> customerList=customerDAOServices.findAll();
		if(customerList.isEmpty())
			throw new CustomerNotFoundException();
		return 	customerList;
	}

	@Override
	public boolean deleteMedicine(int medicineId) throws MedicineNotFoundException {
		medicineDAOServices.findById(medicineId).orElseThrow(()->new MedicineNotFoundException());
		medicineDAOServices.deleteById(medicineId);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) throws CustomerNotFoundException {
		customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		customerDAOServices.deleteById(customerId);
		return true;
	}

	@Override
	public boolean updateMedicine(int medicineId, int quantity) throws MedicineNotFoundException {
		Medicine medicine=medicineDAOServices.findById(medicineId).orElseThrow(()->new MedicineNotFoundException());
		medicine.setStockQuantity(medicine.getStockQuantity()+quantity);
		medicineDAOServices.save(medicine);
		return true;
	}

	@Override
	public boolean updateCustomerMobileNo(int customerId, long mobileNo) throws CustomerNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		customer.setMobileNo(mobileNo);
		customerDAOServices.save(customer);
		return true;
	}

	@Override
	public boolean updateCustomerAddress(Customer customer) throws CustomerNotFoundException {
		Customer customer1=customerDAOServices.findById(customer.getCustomerId()).orElseThrow(()->new CustomerNotFoundException());
		customer1.setAddress(customer.getAddress());
		customerDAOServices.save(customer1);
		return true;
	}

	@Override
	public List<Medicine> viewCustomerMedicine(int customerId) throws CustomerNotFoundException, MedicineNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		Map<Integer, Medicine> mapMedicine=customer.getMedicine();
		List<Medicine> listMedicine=new ArrayList<>(mapMedicine.values());
		if(listMedicine.isEmpty())
			throw new MedicineNotFoundException();
		return listMedicine;
	}
}